import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import api from "../api_routes.txt";
import Box from "./Box";
import Boxedit from './Boxedit'
export default function Dashboard() {
  const [loader, setLoader] = useState(false);
  const [date, setDate] = useState(new Date());
  const [cards, setCards] = useState([]);
  const [options, setOptions] = useState(false);
  const [type, setType] = useState("text");
  const [edit, setEdit] = useState({
    name: "",
    description: "",
    startTime: null,
    endTime: null,
  });
  const auth = "Bearer " + sessionStorage.getItem("token");
  
  const requestOptions = {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      authorization: auth,
    },
  };
  const requestOptions_delete = {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      authorization: auth,
    },
  };
  const OVERLAY_STYLES = {
    position: "relative",
    width: "300px",
    height: "50px",
    backgroundColor: "rgba(0,159,0,0.8)",
    borderRadius: "10px",
    zIndex: 5000,
  };
  async function getcards() {
    setLoader(true);

    var params = {
      date: JSON.stringify(
        date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate()
      ),
    };

    let api_url = await fetch(api);
    let url = await api_url.text();
    var url_1 = new URL(url + "cards");
    url_1.search = new URLSearchParams(params).toString();
   
    fetch(url_1, requestOptions)
      .then((res) => res.json())
      .then((res) => setCards(res.cards));
  }

  async function deletecard(id){
    var params = {
     id:id
    };
   

    let api_url = await fetch(api);
    let url = await api_url.text();
    var url_1 = new URL(url + "cards");
    url_1.search = new URLSearchParams(params).toString();
  
    fetch(url_1, requestOptions_delete)
      .then((res) => res.json()).then(getcards());

  }




  useEffect(() => {
    getcards();
  
  }, [date]);
  function get_hrs(d) {
    let hr_obj = new Date(d);
    return hr_obj.getHours() + ":" + hr_obj.getMinutes();
  }
  function date_change(e) {
    setDate(new Date(e.target.value));
  }
  function date_formatter(d) {
    let date_obj = new Date(d);
    return (
      date_obj.getDate() +
      "/" +
      (date_obj.getMonth() + 1) +
      "/" +
      date_obj.getFullYear()
    );
  }
  function do_something() {
    if(options){
      getcards();
    }
    setOptions(!options);

  }
  function handle_out(e) {
    if (!e.target.value) {
      setType("text");
    }
  }
  function call_edit(){
    if(edit.name.length>0){
      getcards();
    }
    setEdit({ name: "",
    description: "",
    startTime: null,
    endTime: null});
  }
  const page = (
    <div>
      <div className="p-8 place-content-center">
        <p className="text-3xl text-white">
          Your schedule for the date{" "}
          {date.getDate() +
            "/" +
            (date.getMonth() + 1) +
            "/" +
            date.getFullYear()}
        </p>

        <div className="relative max-w-sm place-content-center">
          <label className="text-xl text-white" htmlFor="date">
            Your Date:
          </label>
          <input
            className="rounded-md"
            type={type}
            onMouseOver={() => setType("date")}
            onMouseOut={handle_out}
            id="date"
            name="date"
            onChange={date_change}
          />
        </div>
      </div>
      <button
        onClick={do_something}
        className="bg-gray-400 hover:bg-gray-800 text-white text-xl font-semibold ml-4 py-2 px-4  border-gray-400  rounded-full shadow"
      >
        &#43;
      </button>
      <Box value={options} click={do_something} refresh={getcards}></Box>
      <Boxedit edit={edit} click={call_edit} refresh={getcards}></Boxedit>
      <div className="flex flex-col">
        <div className="overflow-x-auto sm:-mx-6 lg:-mx-8">
          <div className="py-4 inline-block min-w-full sm:px-6 lg:px-8">
            <div className="overflow-hidden">
              <table className="min-w-full text-center overflow-y-auto">
                <thead className="border-b bg-gray-800">
                  <tr>
                    <th
                      scope="col"
                      className="text-sm font-medium text-white px-6 py-4"
                    >
                      Name
                    </th>
                    <th
                      scope="col"
                      className="text-sm font-medium text-white px-6 py-4"
                    >
                      Description
                    </th>
                    <th
                      scope="col"
                      className="text-sm font-medium text-white px-6 py-4"
                    >
                      Start Time
                    </th>
                    <th
                      scope="col"
                      className="text-sm font-medium text-white px-6 py-4"
                    >
                      End Time
                    </th>
                    <th
                      scope="col"
                      className="text-sm font-medium text-white px-6 py-4"
                    >
                      Options
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {cards.map((card) => {
                    return (
                      <tr className="bg-white border-b  hover:bg-gray-400" key={card._id}>
                        <td className="px-6 py-4 whitespace-nowrap text-md font-medium text-black">
                          {card.name}
                        </td>
                        <td className="text-md text-black font-light px-6 py-4 whitespace-nowrap">
                          {card.description}
                        </td>
                        <td className="text-md text-black font-light px-6 py-4 whitespace-nowrap">
                          {date_formatter(card.startTime) +
                            " " +
                            get_hrs(card.startTime) +
                            "hrs"}
                        </td>
                        <td className="text-md text-black font-light px-6 py-4 whitespace-nowrap">
                          {date_formatter(card.endTime) +
                            " " +
                            get_hrs(card.endTime) +
                            "hrs"}
                        </td>
                        <td className="text-md text-black font-light px-6 py-4 whitespace-nowrap">
                          <button onClick={()=>setEdit({name:card.name,description:card.description,startTime:card.startTime,endTime:card.endTime})}className="bg-white hover:bg-indigo-100 text-gray-800 font-semibold ml-4 py-2 px-4 border border-gray-400 rounded shadow">
                            Edit
                          </button>
                          <button onClick={()=>deletecard(card._id)}className="bg-red-200 hover:bg-rose-400 text-gray-800 font-semibold ml-4 py-2 px-4 border border-gray-400 rounded shadow">
                            Delete
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
  return page;
}
